# The Shell

Dark color theme for [Ghost](http://github.com/tryghost/ghost/) platform.

![image](https://user-images.githubusercontent.com/1761114/55421430-dc7f8e80-5581-11e9-9db8-ad3071f09098.png)

Demo lives here: [https://ghostintheshell.ghost.io](https://ghostintheshell.ghost.io/).

----

###### Check out  [Tabs Closer](https://chrome.google.com/webstore/detail/kbjdilnofjdfokcgnpfcjogadbepemno) - Google Chrome extension which close all tabs of same domain in one click

